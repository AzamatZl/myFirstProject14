package lesson1;

public class Main3 {
    public static void main(String[] args) {
        int mark = 233;
        if (mark == 2) {
            System.out.println("Плохо");
        } else if (mark == 3) {
            System.out.println("Удовлетворительно");
        } else if (mark == 4) {
            System.out.println("Хорошо");
        } else if (mark == 5) {
            System.out.println("Отлично");
        }else{
            System.out.println("!!!!!!!!!");
        }
    }
}
